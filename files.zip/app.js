// Frontend logic. API_BASE can point to a separately hosted backend, e.g. window.API_BASE='https://my-api.onrender.com/api'
const API=window.API_BASE||'/api';
let SLOTS=[],CATS=[],EVENTS=[],zones=[],slot='afternoon',pslot='afternoon',hl=null;
const $=id=>document.getElementById(id);
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const level=db=>db<45?['quiet','--q']:db<60?['moderate','--m']:db<70?['noisy','--n']:['very noisy','--v'];
const col=db=>`var(${level(db)[1]})`;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

async function api(path,opts={},admin=false){
 const h={'Content-Type':'application/json'};if(admin)h['X-API-Key']=$('key').value;
 const r=await fetch(API+path,{...opts,headers:h});
 if(!r.ok){let m=r.statusText;try{const j=await r.json();m=typeof j.detail==='string'?j.detail:JSON.stringify(j.detail)}catch(e){}throw new Error(m)}
 return r.json()}
const loadZones=async()=>{zones=await api('/zones');render()};

async function init(){
 const m=await api('/meta');C=await api('/campus');initMap();SLOTS=m.slots;CATS=m.cats;EVENTS=m.events;slot=pslot=m.current_slot;
 $('slot').innerHTML=SLOTS.map(s=>`<option ${s===slot?'selected':''}>${s}</option>`).join('');
 $('cat').innerHTML='<option value="">All categories</option>'+CATS.map(c=>`<option>${c}</option>`).join('');
 $('aCat').innerHTML=CATS.map(c=>`<option>${c}</option>`).join('');
 $('event').innerHTML=EVENTS.map(e=>`<option>${e}</option>`).join('');
 $('aDb').innerHTML=SLOTS.map(s=>`<div><label class="mono">${s} dB</label><input type="number" min="20" max="110" value="45" data-s="${s}"></div>`).join('');
 $('pslots').innerHTML=SLOTS.map(s=>`<button data-s="${s}">${s}</button>`).join('');
 await loadZones()}

$('tabs').onclick=e=>{const t=e.target.closest('button');if(t)go(t.dataset.t)};
function go(t){document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));
 ['heat','pred','ins','admin'].forEach(id=>$(id).hidden=id!==t);render();if(t==='heat'&&map)setTimeout(()=>map.invalidateSize(),50);if(t==='admin')initPick()}

// heatmap
const visible=()=>{const q=$('q').value.trim().toLowerCase(),c=$('cat').value;
 return zones.filter(z=>(!c||z.cat===c)&&(!q||(z.name+' '+z.cat).toLowerCase().includes(q)))};
function drawHeat(){
 const v=visible();$('cnt').textContent=zones.length+' zones';$('vis').textContent=v.length+' visible';
 $('mapTitle').textContent='Noise field / '+slot;
 $('empty').style.display=v.length?'none':'grid';
 $('empty').innerHTML=zones.length?'<div><b>No matches</b><p>Try another category or search term.</p></div>':'<div><b>No fixed zones yet</b><p>Add a location from Admin to populate the map.</p></div>';
 drawPins(v)}
async function showTip(id){const z=zones.find(z=>z.id===id);if(!z)return;hl=id;const d=z.db[slot];drawHeat();
 $('tip').innerHTML=`<b>${esc(z.name)}</b> (${z.cat}) &mdash; ${d} dB, ${level(d)[0]} in the ${slot}.<br>All slots: ${SLOTS.map(s=>s+' '+z.db[s]).join(' / ')}<br><span id="nx">Loading forecast…</span>`;
 try{const f=await api('/forecast/'+id);$('nx').innerHTML='<b>AI forecast:</b> '+f.forecast.map(x=>`${x.slot} ${x.predicted} dB`).join(' &rarr; ')}catch(e){$('nx').textContent=''}}
$('slot').onchange=e=>{slot=e.target.value;drawHeat()};$('cat').onchange=drawHeat;$('q').oninput=drawHeat;

$('quietBtn').onclick=async()=>{go('heat');
 try{const b=await api(`/quietest?slot=${slot}&cat=${encodeURIComponent($('cat').value)}`);
  await showTip(b.id);$('tip').innerHTML=`<b>Quietest (AI-predicted): ${esc(b.name)}</b> &mdash; ${b.predicted} dB in the ${slot}.`;
  $('map').scrollIntoView({behavior:'smooth',block:'center'})}
 catch(e){$('tip').innerHTML='<b>Nothing to rank yet.</b> Add zones in Admin first.'}};

// predictions (from backend ML model)
async function drawPred(){
 document.querySelectorAll('#pslots button').forEach(b=>b.classList.toggle('on',b.dataset.s===pslot));
 if(!zones.length){$('plist').innerHTML='<div style="text-align:center;padding:60px 20px"><b style="font-size:20px">Predictions will appear here</b><p style="color:var(--mut)">Add fixed campus zones to generate forecasts.</p></div>';return}
 const list=await api(`/predict?slot=${pslot}&event=${$('event').value||'normal'}`);
 $('plist').innerHTML=list.map((r,i)=>`<div class="row" data-id="${r.id}"><div><b>${i+1}. ${esc(r.name)}</b></div><div class="mono" style="text-align:right;color:${col(r.predicted)}">${r.predicted} dB</div><small>${r.cat} &middot; expected ${r.level} &middot; entered ${r.entered} dB</small><div class="bar"><i style="width:${Math.min(100,r.predicted)}%;background:${col(r.predicted)}"></i></div></div>`).join('')}
$('pslots').onclick=e=>{const b=e.target.closest('button');if(b){pslot=b.dataset.s;drawPred()}};
$('event').onchange=drawPred;
$('plist').onclick=async e=>{const r=e.target.closest('.row');if(!r)return;
 const f=await api(`/forecast/${r.dataset.id}?event=${$('event').value}`);
 $('fc').hidden=false;$('fc').innerHTML=`<div class="mono" style="color:var(--acc)">Future prediction</div><h3 style="font-weight:300;margin:10px 0">${esc(f.zone)}: next 4 slots</h3>`+
 f.forecast.map(x=>`<div class="zl"><span class="mono">${x.slot}</span><b style="color:${col(x.predicted)}">${x.predicted} dB &middot; ${x.level}</b></div>`).join('');
 $('fc').scrollIntoView({behavior:'smooth'})};

// insights
function drawIns(){
 const all=zones.flatMap(z=>SLOTS.map(s=>z.db[s]));
 $('s1').textContent=zones.length;$('s2').textContent=zones.filter(z=>z.db[slot]<45).length;
 $('s3').textContent=Math.round(avg(all))+' dB';
 const best=[...zones].sort((a,b)=>avg(SLOTS.map(s=>a.db[s]))-avg(SLOTS.map(s=>b.db[s])))[0];
 $('s4').textContent=best?best.name:'\u2014';
 const av=SLOTS.map(s=>zones.length?avg(zones.map(z=>z.db[s])):0),max=Math.max(100,...av);
 $('chart').innerHTML=av.map(a=>`<div>${a?Math.round(a):''}<i style="height:${a/max*85}%;${a?'background:'+col(a):''}"></i></div>`).join('');
 $('axis').innerHTML=SLOTS.map(s=>`<span>${s}</span>`).join('')}

// admin (API-key protected)
const msg=t=>$('aMsg').textContent=t;
$('aAdd').onclick=async()=>{
 const name=$('aName').value.trim();if(!name)return msg('Enter a location name first.');
 const db={};document.querySelectorAll('#aDb input').forEach(i=>db[i.dataset.s]=+i.value);
 try{await api('/admin/zones',{method:'POST',body:JSON.stringify({name,cat:$('aCat').value,x:+$('aX').value,y:+$('aY').value,db})},true);
  $('aName').value='';msg('Saved '+name+'. Model retrained.');await loadZones()}catch(e){msg('Error: '+e.message)}};
$('sample').onclick=async()=>{try{await api('/admin/sample',{method:'POST'},true);msg('Reset to sample data.');await loadZones()}catch(e){msg('Error: '+e.message)}};
$('clear').onclick=async()=>{if(zones.length&&confirm('Delete all zones?')){try{await api('/admin/zones',{method:'DELETE'},true);hl=null;await loadZones()}catch(e){msg('Error: '+e.message)}}};
$('zl').onclick=async e=>{const b=e.target.closest('button[data-d]');if(!b)return;
 try{await api('/admin/zones/'+b.dataset.d,{method:'DELETE'},true);await loadZones()}catch(err){msg('Error: '+err.message)}};
function drawAdmin(){$('zl').innerHTML=zones.length?zones.map(z=>`<div class="zl"><span><b>${esc(z.name)}</b><br><small style="color:var(--mut)">${z.cat} &middot; ${SLOTS.map(s=>z.db[s]).join(' / ')} dB</small></span><button class="btn ghost" data-d="${z.id}">Delete</button></div>`).join(''):'<p class="note">No zones saved yet.</p>'}

function render(){drawHeat();drawPred();drawIns();drawAdmin();drawPick()}
// ---- real map (Leaflet + OpenStreetMap) ----
let C={lat:17.72158,lng:74.02065,name:'Yashoda Technical Campus, Satara',zoom:17},map=null,layer=null,pick=null,pickLayer=null;
const DLAT=.000022,DLNG=.000028;                       // 0-100 grid -> roughly 250m x 300m around the campus centre
const toLL=z=>[C.lat+(50-z.y)*DLAT,C.lng+(z.x-50)*DLNG];
function baseMap(el){const m=L.map(el).setView([C.lat,C.lng],C.zoom);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(m);
 L.rectangle([[C.lat-50*DLAT,C.lng-50*DLNG],[C.lat+50*DLAT,C.lng+50*DLNG]],{color:'#4fe0b0',weight:1,dashArray:'6 6',fill:false}).addTo(m).bindTooltip(C.name);return m}
function initMap(){if(typeof L==='undefined'){$('map').innerHTML='<p class="note" style="padding:20px">The map needs internet (Leaflet + OpenStreetMap).</p>';return}
 map=baseMap('map');layer=L.layerGroup().addTo(map)}
function drawPins(v){if(!map)return;layer.clearLayers();
 v.forEach(z=>{const d=z.db[slot];
  const ic=L.divIcon({className:'',html:`<div class="zone2 ${z.id===hl?'hl':''}" style="background:${col(d)}">${Math.round(d)}</div>`,iconSize:[34,34],iconAnchor:[17,17]});
  L.marker(toLL(z),{icon:ic,title:z.name+', '+d+' dB'}).on('click',()=>showTip(z.id)).addTo(layer)})}
function initPick(){if(typeof L==='undefined')return;
 if(!pick){pick=baseMap('pick');pickLayer=L.layerGroup().addTo(pick);
  pick.on('click',e=>{const cl=n=>Math.max(0,Math.min(100,n));
   $('aX').value=cl(50+(e.latlng.lng-C.lng)/DLNG).toFixed(1);$('aY').value=cl(50-(e.latlng.lat-C.lat)/DLAT).toFixed(1);drawPick()})}
 setTimeout(()=>{pick.invalidateSize();drawPick()},50)}
function drawPick(){if(!pick)return;pickLayer.clearLayers();
 zones.forEach(z=>L.circleMarker(toLL(z),{radius:6,color:'#fff',weight:1,fillColor:'#8fa0b5',fillOpacity:.9}).bindTooltip(z.name).addTo(pickLayer));
 L.marker(toLL({x:+$('aX').value||50,y:+$('aY').value||50})).addTo(pickLayer)}
init();

// make it an installable app (PWA)
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));

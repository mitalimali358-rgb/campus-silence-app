# Campus Silence Heatmap - Yashoda Technical Campus, Satara

All files sit in one folder (no sub-folders).

| File | Role |
|---|---|
| backend.py | BACKEND - FastAPI + Random Forest ML + API |
| index.html, style.css, app.js | FRONTEND - page, design, logic |
| manifest.json, sw.js, icon-192.png, icon-512.png | Makes it installable as a phone app |
| requirements.txt, render.yaml | Hosting setup (Render) |

Run locally:  pip install -r requirements.txt  then  python backend.py  ->  http://localhost:8000
Admin key: ADMIN_API_KEY (default campus123).  Campus centre: CAMPUS_LAT / CAMPUS_LNG.
